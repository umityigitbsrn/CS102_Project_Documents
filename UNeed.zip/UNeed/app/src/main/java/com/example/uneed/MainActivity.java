package com.example.uneed;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ApplicationInfo;
import android.os.AsyncTask;
import android.os.Handler;
import android.support.design.widget.TabLayout;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import com.example.uneed.structures.User;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;

import static android.view.View.GONE;

public class MainActivity extends AppCompatActivity {

    public static final int CODE_GET_REQUEST = 1024;
    public static final int CODE_POST_REQUEST = 1025;

    public static JSONObject object;
    public static User user;
    public static boolean checkLogin;
    public static TextView resultText;
    public static EditText usernameText;
    public static EditText passwordText;
    public static EditText emailText;
    public static TabLayout tabLayout;
    private static Context mContext;

    PerformNetworkRequest request;


    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        mContext = this;
        resultText = findViewById(R.id.textView);
        usernameText = findViewById(R.id.editText);
        passwordText = findViewById(R.id.editText2);
        emailText = findViewById(R.id.editText3);
        tabLayout = findViewById(R.id.tabLayout);
        tabLayout.addOnTabSelectedListener(new TabLayout.OnTabSelectedListener()
        {
            @Override
            public void onTabSelected(TabLayout.Tab tab)
            {
                Log.i("TAG", "onTabSelected: " + tab.getText());
                if(tab.getPosition() == 0)
                {
                    emailText.setVisibility(View.GONE);
                    findViewById(R.id.button2).setVisibility(GONE);
                    findViewById(R.id.button).setVisibility(View.VISIBLE);
                    resultText.setText("");
                }else
                {
                    emailText.setVisibility(View.VISIBLE);
                    findViewById(R.id.button2).setVisibility(View.VISIBLE);
                    findViewById(R.id.button).setVisibility(GONE);
                    resultText.setText("");
                }
            }

            @Override
            public void onTabUnselected(TabLayout.Tab tab)
            {

            }

            @Override
            public void onTabReselected(TabLayout.Tab tab)
            {

            }
        });
    }

    public static void checkLogin()
    {

        try
        {
            if(object.length() != 0)
            {
                if(object.getBoolean("error") == false)
                {
                    user = new User(object.getInt("userid"),object.getString("username"),object.getString("email"),object.getString("password"));
                    Intent i = new Intent(mContext, HomePage.class);
                    i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                    i.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK);
                    mContext.startActivity(i);
                }
            }
        } catch (JSONException e)
        {
            e.printStackTrace();
        }
    }

    public void login(View view)
    {
        String username = usernameText.getText().toString().trim();
        String password = passwordText.getText().toString().trim();

        //validating the inputs
        if (TextUtils.isEmpty(username)) {
            usernameText.setError("Please enter name");
            usernameText.requestFocus();
            return;
        }

        if (TextUtils.isEmpty(password)) {
            passwordText.setError("Please enter password");
            passwordText.requestFocus();
            return;
        }

        //if validation passes

        HashMap<String, String> params = new HashMap<>();
        params.put("username", username);
        params.put("password", password);


        //Calling the create user API
        request = new PerformNetworkRequest(Api.URL_LOGIN, params, CODE_POST_REQUEST);
        checkLogin = true;
        request.execute();
    }

    public void register(View view) {
        String username = usernameText.getText().toString().trim();
        String email = emailText.getText().toString().trim();
        String password = passwordText.getText().toString().trim();

        //validating the inputs
        if (TextUtils.isEmpty(username)) {
            usernameText.setError("Please enter name");
            usernameText.requestFocus();
            return;
        }

        if (TextUtils.isEmpty(email)) {
            emailText.setError("Please enter email");
            emailText.requestFocus();
            return;
        }

        if (TextUtils.isEmpty(password)) {
            passwordText.setError("Please enter password");
            passwordText.requestFocus();
            return;
        }

        //if validation passes

        HashMap<String, String> params = new HashMap<>();
        params.put("username", username);
        params.put("email", email);
        params.put("password", password);
        request = new PerformNetworkRequest(Api.URL_CREATE_USER, params, CODE_POST_REQUEST);
        request.execute();
    }
}

//inner class to perform network request extending an AsyncTask
class PerformNetworkRequest extends AsyncTask<Void, Void, String> {

    //the url where we need to send the request
    String url;
    //the parameters
    HashMap<String, String> params;

    //the request code to define whether it is a GET or POST
    int requestCode;

    //constructor to initialize values
    PerformNetworkRequest(String url, HashMap<String, String> params, int requestCode) {
        this.url = url;
        this.params = params;
        this.requestCode = requestCode;
    }

    //when the task started displaying a progressbar
    @Override
    protected void onPreExecute() {
        super.onPreExecute();
        //MainActivity.progressBar.setVisibility(View.VISIBLE);
        MainActivity.resultText.setText("Processing...");
    }


    //this method will give the response from the request
    @Override
    protected void onPostExecute(String s) {
        super.onPostExecute(s);
        //MainActivity.progressBar.setVisibility(GONE);
        try {
            MainActivity.object = new JSONObject(s);
            //if (!object.getBoolean("error")) {
            MainActivity.checkLogin();
                MainActivity.resultText.setText(MainActivity.object.getString("message"));
                //refreshing the herolist after every operation
                //so we get an updated list
                //we will create this method right now it is commented
                //because we haven't created it yet
                //refreshHeroList(object.getJSONArray("heroes"));
            //}
        } catch (JSONException e) {
            e.printStackTrace();
        }
    }

    //the network operation will be performed in background
    @Override
    protected String doInBackground(Void... voids) {
        RequestHandler requestHandler = new RequestHandler();

        if (requestCode == MainActivity.CODE_POST_REQUEST)
            return requestHandler.sendPostRequest(url, params);


        if (requestCode == MainActivity.CODE_GET_REQUEST)
            return requestHandler.sendGetRequest(url);

        return null;
    }
}
